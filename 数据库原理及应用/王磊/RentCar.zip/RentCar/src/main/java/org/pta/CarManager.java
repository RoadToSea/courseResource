package org.pta;

import java.sql.*;
import java.util.Scanner;

public class CarManager {
    //连接数据库操作
    private String dbUrl;
    private String dbUsername;
    private String dbPassword;

    public CarManager(String dbUrl, String dbUsername, String dbPassword) {
        this.dbUrl = dbUrl;
        this.dbUsername = dbUsername;
        this.dbPassword = dbPassword;
    }

    public CarManager() {

    }

    public void addVehicle() {
        System.out.println("请选择要添加的车辆类型：");
        System.out.println("1、汽车  2、大巴  3、卡车");
        Scanner sc = new Scanner(System.in);
        int i = sc.nextInt();
        switch (i){
            case 1:
                addCar();break;
            case 2:
                addBus();break;
            case 3:
                addTruck();break;
        }
    }

    private void addTruck() {
        Scanner sc = new Scanner(System.in);
        Truck truck = new Truck();
        System.out.println("品牌：");
        truck.setBrand(sc.next());
        System.out.println("车牌号：");
        truck.setVehicleLd(sc.next());
        System.out.println("日租金：");
        truck.setPerRend(sc.nextInt());
        System.out.println("载重：");
        truck.setWeight(sc.nextFloat());

        try {
            Connection connection = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            String query1 = "SELECT MAX(id) AS max_id FROM truck";
            PreparedStatement preparedStatement1 = connection.prepareStatement(query1);
            ResultSet resultSet = preparedStatement1.executeQuery();

            if (resultSet.next()) {
                truck.setId(resultSet.getInt("max_id")+1);
            }
            preparedStatement1.close();
            String query = "INSERT INTO truck (id, brand, vehicleLd,perRent,weight) VALUES (?, ?, ?, ?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1,truck.getId());
            preparedStatement.setString(2, truck.getBrand());
            preparedStatement.setString(3, truck.getVehicleLd());
            preparedStatement.setInt(4, truck.getPerRend());
            preparedStatement.setFloat(5, truck.getWeight());
            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void addBus() {
        Scanner sc = new Scanner(System.in);
        Bus bus = new Bus();
        System.out.println("品牌：");
        bus.setBrand(sc.next());
        System.out.println("车牌号：");
        bus.setVehicleLd(sc.next());
        System.out.println("日租金：");
        bus.setPerRend(sc.nextInt());
        System.out.println("座位数：");
        bus.setSeats(sc.nextInt());

        try {
            Connection connection = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            String query1 = "SELECT MAX(id) AS max_id FROM bus";
            PreparedStatement preparedStatement1 = connection.prepareStatement(query1);
            ResultSet resultSet = preparedStatement1.executeQuery();

            if (resultSet.next()) {
                bus.setId(resultSet.getInt("max_id")+1);
            }
            preparedStatement1.close();
            String query = "INSERT INTO bus (id, brand, vehicleLd,perRent,seats) VALUES (?, ?, ?, ?,?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1,bus.getId());
            preparedStatement.setString(2, bus.getBrand());
            preparedStatement.setString(3, bus.getVehicleLd());
            preparedStatement.setInt(4, bus.getPerRend());
            preparedStatement.setInt(5, bus.getSeats());
            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void addCar() {
        Scanner sc = new Scanner(System.in);
        Car car = new Car();
        System.out.println("品牌：");
        car.setBrand(sc.next());
        System.out.println("型号：");
        car.setType(sc.next());
        System.out.println("车牌号：");
        car.setVehicleLd(sc.next());
        System.out.println("日租金：");
        car.setPerRend(sc.nextInt());

        try {
            Connection connection = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            String query1 = "SELECT MAX(id) AS max_id FROM car";
            PreparedStatement preparedStatement1 = connection.prepareStatement(query1);
            ResultSet resultSet = preparedStatement1.executeQuery();

            if (resultSet.next()) {
                car.setId(resultSet.getInt("max_id")+1);
            }
            preparedStatement1.close();
            String query = "INSERT INTO car (id, Brand, type,VehicleLd,PerRent) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1,car.getId());
            preparedStatement.setString(2, car.getBrand());
            preparedStatement.setString(3, car.getType());
            preparedStatement.setString(4, car.getVehicleLd());
            preparedStatement.setInt(5, car.getPerRend());
            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void selectAllVehicle() {//查询所有车辆
        selectCar();
        selectBus();
        selectTruck();
//        System.out.println("请选择要查询的车辆类型：");
//        System.out.println("1、汽车  2、大巴  3、卡车");
//        Scanner sc = new Scanner(System.in);
//        int i = sc.nextInt();
//        switch (i){
//            case 1:
//                selectCar();
//            case 2:
//                selectBus();
//            case 3:
//                selectTruck();
//        }
    }

    public void selectTruck() {
        try {
            Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
            String query = "SELECT * FROM truck";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Truck truck = new Truck();
                truck.setId(resultSet.getInt("id"));
                truck.setBrand(resultSet.getString("brand"));
                truck.setVehicleLd((resultSet.getString("vehicleLd")));
                truck.setPerRend((resultSet.getInt("perRent")));
                truck.setWeight(resultSet.getFloat("weight"));
                System.out.println(truck.toString());
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void selectBus() {
        try {
            Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
            String query = "SELECT * FROM bus";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Bus bus = new Bus();
                bus.setId(resultSet.getInt("id"));
                bus.setBrand(resultSet.getString("brand"));
                bus.setVehicleLd((resultSet.getString("vehicleLd")));
                bus.setPerRend((resultSet.getInt("perRent")));
                bus.setSeats(resultSet.getInt("seats"));
                System.out.println(bus.toString());
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void selectCar() {
        try {
            Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
            String query = "SELECT * FROM car";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Car car = new Car();
                car.setId(resultSet.getInt("id"));
                car.setBrand(resultSet.getString("brand"));
                car.setType(resultSet.getString("type"));
                car.setVehicleLd((resultSet.getString("vehicleLd")));
                car.setPerRend((resultSet.getInt("perRent")));
                System.out.println(car.toString());
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteVehicle() {//车辆删除操作
        System.out.println("请选择要删除的车辆类型：");
        System.out.println("1、汽车  2、大巴  3、卡车");
        Scanner sc = new Scanner(System.in);
        int i = sc.nextInt();
        switch (i){
            case 1:
                deleteCar();break;
            case 2:
                deleteBus();break;
            case 3:
                deleteTruck();break;
        }
    }

    private void deleteTruck() {
        System.out.println("请输入将要删除的车牌号：");
        Scanner sc = new Scanner(System.in);
        String vehicleLd = sc.next();

        try {
            Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
            String query = "DELETE FROM truck WHERE vehicleLd = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, vehicleLd);
            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void deleteBus() {
        System.out.println("请输入将要删除的车牌号：");
        Scanner sc = new Scanner(System.in);
        String vehicleLd = sc.next();

        try {
            Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
            String query = "DELETE FROM bus WHERE vehicleLd = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, vehicleLd);
            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void deleteCar() {
        System.out.println("请输入将要删除的车牌号：");
        Scanner sc = new Scanner(System.in);
        String vehicleLd = sc.next();

        try {
            Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
            String query = "DELETE FROM car WHERE vehicleLd = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, vehicleLd);
            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Bus selectBusById(int id) {//根据Id查询车俩信息
        Bus bus = new Bus();
        try {
            Connection connection = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            String query = "SELECT * FROM bus WHERE id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                bus.setId(resultSet.getInt("id"));
                bus.setBrand(resultSet.getString("brand"));
                bus.setVehicleLd(resultSet.getString("vehicleLd"));
                bus.setPerRend(resultSet.getInt("perRent"));
                bus.setSeats(resultSet.getInt("seats"));
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bus;
    }

    public Truck selectTruckById(int id) {
        Truck truck = new Truck();
        try {
            Connection connection = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            String query = "SELECT * FROM truck WHERE id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                truck.setId(resultSet.getInt("id"));
                truck.setBrand(resultSet.getString("brand"));
                truck.setVehicleLd(resultSet.getString("vehicleLd"));
                truck.setPerRend(resultSet.getInt("perRent"));
                truck.setWeight(resultSet.getFloat("weight"));
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return truck;
    }

    public Car selectCarById(int id) {
        Car car = new Car();
        try {
            Connection connection = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            String query = "SELECT * FROM car WHERE id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                car.setId(resultSet.getInt("id"));
                car.setBrand(resultSet.getString("brand"));
                car.setVehicleLd(resultSet.getString("vehicleLd"));
                car.setPerRend(resultSet.getInt("perRent"));
                car.setType(resultSet.getString("type"));
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return car;
    }
}
