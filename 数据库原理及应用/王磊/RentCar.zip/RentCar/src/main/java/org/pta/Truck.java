package org.pta;


import java.util.Random;
import java.util.Scanner;

public class Truck extends Vehicle{//卡车
    private int id;
    private float weight;//重量

    @Override
    public String toString() {
        return "Truck{" +
                "id=" + id +",vehicleLd='" + getVehicleLd() + '\'' +
                ", brand='" + getBrand() + '\'' +
                ", perRend=" + getPerRend()+
                ", weight=" + weight +
                '}';
    }

    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public void menu(String username) {
        UserManager userManager = new UserManager("jdbc:mysql://127.0.0.1:3306/crs", "root", "2781307050.wl");
        CarManager carManager = new CarManager("jdbc:mysql://127.0.0.1:3306/crs", "root", "2781307050.wl");
        carManager.selectTruck();
        System.out.println("请选择你所要租赁的车辆id：");
        Scanner sc = new Scanner(System.in);
        int id = sc.nextInt();
        Truck truck = carManager.selectTruckById(id);
        System.out.println("请选择你所要租赁的天数：");
        int days = sc.nextInt();
        float v = truck.calRent(days);
        if (userManager.selectBalance(username)>v) {
            Vehicle vehicle = new Vehicle();
            System.out.println("租赁成功!");
            vehicle.addMoney(username,"租赁大巴"+truck.toString(),v);
            userManager.subMoney(username,v);
        }else {
            System.out.println("余额不够，请充值!");
        }
//        System.out.println("1、解放    2、重汽");
//        System.out.println("请选择你要租赁的卡车品牌：");
//        Scanner sc = new Scanner(System.in);
//        int i = sc.nextInt();
//        if (i == 1) {
//            System.out.println("请输入卡车的载货重量(单位为吨)：");
//            double j = sc.nextDouble();
//            int k= (int) (j/2.37+1);
//            setPerRend(900);
//            System.out.println("请输入您要租赁的天数：");
//            float v = calRent(sc.nextInt());
//            Random random = new Random();
//            int r = random.nextInt(1, 2);
//            if (r==1){
//                setVehicleLd("京6566785");
//            }else if (r==2){
//                setVehicleLd("京8694397");
//            }
//            System.out.println("分配给您的车牌号是："+getVehicleLd());
//            System.out.println("您需要支付的租赁费用是："+v*k+"元");
//
//        }
//        else if (i == 2) {
//            System.out.println("请输入卡车的载货重量(单位为吨)：");
//            double j = sc.nextDouble();
//            int k= (int) (j/5.1+1);
//            setPerRend(1600);
//            System.out.println("请输入您要租赁的天数：");
//            float v = calRent(sc.nextInt());
//            Random random = new Random();
//            int r = random.nextInt(1, 2);
//            if (r==1){
//                setVehicleLd("京6566749");
//            }else if (r==2){
//                setVehicleLd("京8124397");
//            }
//            System.out.println("分配给您的车牌号是："+getVehicleLd());
//            System.out.println("您需要支付的租赁费用是："+v*k+"元");
//        }
    }
}