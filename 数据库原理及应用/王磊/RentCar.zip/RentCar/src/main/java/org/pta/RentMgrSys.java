package org.pta;

import java.util.Scanner;

public class RentMgrSys {
    public static void main(String[] args) {
        start();
    }

    private static void start(){
        Scanner sc = new Scanner(System.in);
        System.out.println("***********欢迎来到腾飞汽车租赁系统***********");
        System.out.println("请选择登录或注册：");
        System.out.println("1、登录 2、注册");
        int x = sc.nextInt();
        switch (x) {
            case 1 -> Login();
            case 2 -> Register();
            default -> {
                System.out.println("输入错误，请重新输入！");
                start();
            }
        }
    }

    private static void Register() {
        System.out.println("*************注册*************");
        UserManager userManager = new UserManager("jdbc:mysql://127.0.0.1:3306/crs", "root", "2781307050.wl");
        User user = new User();
        Scanner scanner = new Scanner(System.in);
        System.out.println("用户名: ");
        String username = scanner.next();
        user.setUsername(username);
        System.out.println("密码: ");
        String password = scanner.next();
        user.setPassword(password);
        user.setIsVip(0);
        user.setIsManager(0);
        user.setBalance(0);
        boolean addUser = userManager.addUser(user);
        if (!addUser) {
            System.out.println("用户已存在，请换个用户名再试试");
            start();
        }else {
            System.out.println("注册成功！");
            Login();
        }
    }

    private static void Login() {
        System.out.println("*************登录*************");
        UserManager userManager = new UserManager("jdbc:mysql://127.0.0.1:3306/crs", "root", "2781307050.wl");
        System.out.print("输入用户名: ");
        Scanner scanner = new Scanner(System.in);
        String username = scanner.nextLine();
        System.out.print("输入密码: ");
        String password = scanner.nextLine();

        if (userManager.authenticateUser(username, password)) {
            System.out.println("身份验证成功！.");
            User user = userManager.getUserByUsername(username);
            if (user.getIsManager()==1){
                adminMenu();
            }else if(user.getIsVip()==1){
                vipMenu(username);
            }else userMenu(username);

        } else {
            System.out.println("登陆失败,请重新登录");
            Login();
        }
    }

    private static void userMenu(String username) {
        UserManager userManager = new UserManager("jdbc:mysql://127.0.0.1:3306/crs", "root", "2781307050.wl");
        CarManager carManager = new CarManager("jdbc:mysql://127.0.0.1:3306/crs", "root", "2781307050.wl");
        System.out.println("*************用户界面*************");
        Scanner sc = new Scanner(System.in);
        System.out.println("请选择你要进行的操作：");
        System.out.println("1、租赁车辆");
        System.out.println("2、查看余额");
        System.out.println("3、充值");
        System.out.println("4、退出");
        int i = sc.nextInt();
        switch (i){
            case 1:new Car().menu(username);userMenu(username);break;
            case 2:
                double balance = userManager.selectBalance(username);
                System.out.println("您的余额还剩"+balance+"人民币");userMenu(username);break;
            case 3:userManager.addMoney(username);userMenu(username);break;
            case 4:
                System.out.println("欢迎下次光临！");break;
            default:System.out.println("非法输入，请重新输入！");userMenu(username);
        }
    }

    private static void vipMenu(String username) {
        UserManager userManager = new UserManager("jdbc:mysql://127.0.0.1:3306/crs", "root", "2781307050.wl");
        CarManager carManager = new CarManager("jdbc:mysql://127.0.0.1:3306/crs", "root", "2781307050.wl");
        System.out.println("*************Vip用户专属界面*************");
        Scanner sc = new Scanner(System.in);
        System.out.println("请选择你要进行的操作：");
        System.out.println("1、查询所有车辆信息");
        System.out.println("2、租赁车辆");
        System.out.println("3、查看余额");
        System.out.println("4、充值");
        System.out.println("5、退出");
        int i = sc.nextInt();
        switch (i){
            case 1:carManager.selectAllVehicle();vipMenu(username);break;
            case 2:userManager.Rent(username);vipMenu(username);break;
            case 3:
                double balance = userManager.selectBalance(username);
                System.out.println("您的余额还剩"+balance+"人民币");vipMenu(username);break;
            case 4:userManager.addMoney(username);vipMenu(username);break;
            case 5:
                System.out.println("欢迎下次光临！");break;
            default:System.out.println("非法输入，请重新输入！");vipMenu(username);
        }
    }

    private static void adminMenu() {
        UserManager userManager = new UserManager("jdbc:mysql://127.0.0.1:3306/crs", "root", "2781307050.wl");
        CarManager carManager = new CarManager("jdbc:mysql://127.0.0.1:3306/crs", "root", "2781307050.wl");
        Scanner sc = new Scanner(System.in);
        System.out.println("*************管理员界面*************");
        System.out.println("请选择你要进行的操作：");
        System.out.println("1、查看所有用户信息");
        System.out.println("2、修改用户信息");
        System.out.println("3、删除用户信息");
        System.out.println("4、增加车辆信息");
        System.out.println("5、查询所有车辆信息");
        System.out.println("6、删除车辆信息");
        System.out.println("7、查看总营业额");
        System.out.println("8、查看日志");
        System.out.println("9、退出");
        int i = sc.nextInt();
        switch (i){
            case 1:userManager.selectAllUser();adminMenu();break;
            case 2:userManager.updateUser();adminMenu();break;
            case 3:userManager.deleteUser();adminMenu();break;
            case 4:carManager.addVehicle();adminMenu();break;
            case 5:carManager.selectAllVehicle();adminMenu();break;
            case 6:carManager.deleteVehicle();adminMenu();break;
            case 7:
                System.out.println("总营业额："+userManager.getAllProfit());adminMenu();break;
            case 8:userManager.getLog();adminMenu();break;
            case 9:System.out.println("欢迎下次光临！");break;
            default:System.out.println("非法输入，请重新输入！");adminMenu();


        }

    }

//    private static void Menu() {
//        Scanner sc = new Scanner(System.in);
//        System.out.println("***********欢迎光临腾飞汽车租赁公司***********");
//        System.out.println("1、轿车    2、客车    3、卡车");
//        System.out.println("请选择你要租赁的汽车类型：");
//        int i = sc.nextInt();
//        switch (i){
//            case 1:
//                Car car = new Car();car.menu();break;
//            case 2:
//                Bus bus = new Bus();bus.menu();break;
//            case 3:
//                Truck truck = new Truck();truck.menu();
//                break;
//            default:
//                System.out.println("输入错误，请重新输入！");
//        }
//    }
}

