package org.pta;

public class User {
    private int id;
    private String username;
    private String password;
    private int isVip;
    private int isManager;
    private double balance;

    public User() {

    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", isVip=" + isVip +
                ", isManager=" + isManager +
                '}';
    }

    public User(int id, String username, String password, int isVip, int isManager,double balance) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.isVip = isVip;
        this.isManager = isManager;
        this.balance = balance;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getIsVip() {
        return isVip;
    }

    public void setIsVip(int isVip) {
        this.isVip = isVip;
    }

    public int getIsManager() {
        return isManager;
    }

    public void setIsManager(int isManager) {
        this.isManager = isManager;
    }
}
