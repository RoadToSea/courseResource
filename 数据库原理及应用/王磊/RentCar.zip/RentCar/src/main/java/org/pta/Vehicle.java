package org.pta;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Vehicle {//车（父类）
    private String vehicleLd;//车牌号
    private String brand;//品牌
    private int perRend;//日租金

//    @Override
//    public String toString() {
//        return "Vehicle{" +
//                "vehicleLd='" + vehicleLd + '\'' +
//                ", brand='" + brand + '\'' +
//                ", perRend=" + perRend +
//                '}';
//    }

    public String getVehicleLd() {
        return vehicleLd;
    }

    public void setVehicleLd(String vehicleLd) {
        this.vehicleLd = vehicleLd;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getPerRend() {
        return perRend;
    }

    public void setPerRend(int perRend) {
        this.perRend = perRend;
    }
    public  float calRent(int days) {//计算租金
        float rent = 0;
        if (days >= 0 && days < 3) {
            rent = (float) (perRend * days);
        } else if (days >= 3 && days < 7) {
            rent =  (float) (perRend * days * 0.9);
        } else if (days >= 7 && days < 30) {
            rent =  (float) (perRend * days * 0.8);
        } else if (days >= 30 && days < 150) {
            rent =  (float) (perRend * days * 0.7);
        } else if (days >= 150) {
            rent =  (float) (perRend * days * 0.6);
        }
        return rent;
    }
    public void menu(String name){}

    protected void addMoney(String username, String s, float v) {
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/crs", "root", "2781307050.wl");
            String query = "INSERT INTO log (username, action, profit) VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, s);
            preparedStatement.setFloat(3,v);
            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

