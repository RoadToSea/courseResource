package org.pta;

public class Log {
    private int id;
    private String username;
    private String action;//每次交易行为
    private float profit;//每次的收益
    private float all;//总收益

    public Log(int id, String username, String action, float profit, float all) {
        this.id = id;
        this.username = username;
        this.action = action;
        this.profit = profit;
        this.all = all;
    }

    public Log() {

    }

    @Override
    public String toString() {
        return "Log{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", action='" + action + '\'' +
                ", profit=" + profit +
                ", all=" + all +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public float getProfit() {
        return profit;
    }

    public void setProfit(float profit) {
        this.profit = profit;
    }

    public float getAll() {
        return all;
    }

    public void setAll(float all) {
        this.all = all;
    }
}
