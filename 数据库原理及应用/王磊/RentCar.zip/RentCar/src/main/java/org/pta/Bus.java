package org.pta;

import java.sql.*;
import java.util.Random;
import java.util.Scanner;

class Bus extends Vehicle {//大巴
    private int id;
    private int Seats;//座位

    @Override
    public String toString() {
        return "Bus{" +
                "id=" + id +",vehicleLd='" + getVehicleLd() + '\'' +
                ", brand='" + getBrand() + '\'' +
                ", perRend=" + getPerRend()+
                ", Seats=" + Seats +
                '}';
    }

    public int getSeats() {
        return Seats;
    }

    public void setSeats(int seats) {
        Seats = seats;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public void menu(String username) {
        UserManager userManager = new UserManager("jdbc:mysql://127.0.0.1:3306/crs", "root", "2781307050.wl");
        CarManager carManager = new CarManager("jdbc:mysql://127.0.0.1:3306/crs", "root", "2781307050.wl");
        carManager.selectBus();
        System.out.println("请选择你所要租赁的车辆id：");
        Scanner sc = new Scanner(System.in);
        int id = sc.nextInt();
        Bus bus = carManager.selectBusById(id);
        System.out.println("请选择你所要租赁的天数：");
        int days = sc.nextInt();
        float v = bus.calRent(days);
        if (userManager.selectBalance(username)>=v) {
            Vehicle vehicle = new Vehicle();
            System.out.println("租赁成功!");
            vehicle.addMoney(username,"租赁大巴"+bus.toString(),v);
            userManager.subMoney(username,v);
        }
        else {
            System.out.println("余额不够，请充值!");
        }
    }
}
