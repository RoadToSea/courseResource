package org.pta;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class UserManager {
    private String dbUrl;
    private String dbUsername;
    private String dbPassword;

    public UserManager(String dbUrl, String dbUsername, String dbPassword) {
        this.dbUrl = dbUrl;
        this.dbUsername = dbUsername;
        this.dbPassword = dbPassword;
    }

    public UserManager() {

    }

    public boolean addUser(User user) {
        try {
            Connection connection = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            String query1 = "SELECT MAX(id) AS max_id FROM user";
            PreparedStatement preparedStatement1 = connection.prepareStatement(query1);
            ResultSet resultSet = preparedStatement1.executeQuery();

            if (resultSet.next()) {
                user.setId(resultSet.getInt("max_id")+1);
            }
            preparedStatement1.close();
            String query = "INSERT INTO user (id, username, password,isVip,isManager,balance) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1,user.getId());
            preparedStatement.setString(2, user.getUsername());
            preparedStatement.setString(3, user.getPassword());
            preparedStatement.setInt(4, user.getIsVip());
            preparedStatement.setInt(5, user.getIsManager());
            preparedStatement.setDouble(6, user.getBalance());
            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
//            e.printStackTrace();
            return false;
        }
        return true;
    }

    public boolean authenticateUser(String username, String password) {
        //验证密码是否正确
        User user=getUserByUsername(username);
        if (user != null) {
            return user.getPassword().equals(password);
        }
        return false;
    }

    public User getUserByUsername(String username) {
        User user = null;
        try {
            Connection connection = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            String query = "SELECT * FROM user WHERE username = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                user = new User();
                user.setId(resultSet.getInt("id"));
                user.setUsername(resultSet.getString("username"));
                user.setPassword(resultSet.getString("password"));
                user.setIsVip(resultSet.getInt("isVip"));
                user.setIsManager(resultSet.getInt("isManager"));
                user.setBalance(resultSet.getDouble("balance"));
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return user;
    }

    public void selectAllUser() {
        try {
            Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
            String query = "SELECT * FROM user";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                User user = new User();
                user.setId(resultSet.getInt("id"));
                user.setUsername((resultSet.getString("username")));
                user.setPassword((resultSet.getString("password")));
                user.setIsVip(resultSet.getInt("isVip"));
                user.setIsVip(resultSet.getInt("isManager"));
                user.setBalance(resultSet.getDouble("balance"));
                System.out.println(user.toString());
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void updateUser() {
        System.out.println("请输入用户名：");
        Scanner sc = new Scanner(System.in);
        String username = sc.next();
        User user = getUserByUsername(username);
        System.out.println("请输入要修改的信息：");
        System.out.println("密码：");
        String password = sc.next();
        System.out.println("是否Vip：");
        int isVip = sc.nextInt();
        System.out.println("是否管理员：");
        int isManager = sc.nextInt();

        try {
            Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
            String query = "UPDATE user SET password = ?, isVip = ?,isManager = ? WHERE username = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, password);
            preparedStatement.setInt(2, isVip);
            preparedStatement.setInt(3, isManager);
            preparedStatement.setString(4, username);
            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteUser() {
        System.out.println("请输入将要删除的用户名：");
        Scanner sc = new Scanner(System.in);
        String username = sc.next();

        try {
            Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
            String query = "DELETE FROM user WHERE username = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void Rent(String username) {//租赁操作
        System.out.println("您想要租赁的车辆类型：");
        System.out.println("1、汽车  2、大巴  3、卡车");
        Scanner sc = new Scanner(System.in);
        int i = sc.nextInt();
        switch (i){
            case 1:
                new Car().menu(username);break;
            case 2:
                new Bus().menu(username);break;
            case 3:
                new Truck().menu(username);break;
        }
    }

    public double selectBalance(String username) {
        double balance =0;
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/crs", "root", "2781307050.wl");
            String query = "SELECT balance FROM user WHERE username = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                balance = resultSet.getDouble("balance");
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return balance;
    }

    public void subMoney(String username, float v) {
        //支付操作
        double x=selectBalance(username)-v;
        try {
            Connection connection = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            String query = "update user SET balance = ? WHERE username = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setDouble(1, x);
            preparedStatement.setString(2, username);
            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addMoney(String username) {
        Scanner sc = new Scanner(System.in);
        System.out.println("请选择要充值的金额：");
        double v = sc.nextDouble();
        double x=selectBalance(username)+v;
        try {
            Connection connection = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            String query = "UPDATE user SET balance = ? WHERE username = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setDouble(1, x);
            preparedStatement.setString(2, username);
            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public float getAllProfit() {
        //查看总营业额
        float all_pf = 0;
        try {
            Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
            String query = "SELECT MAX(`all`) AS all_pf FROM log";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                 all_pf = resultSet.getFloat("all_pf");
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return all_pf;
    }

    public void getLog() {
        //查看日志
        List<Log> logs = new ArrayList<>();
        try {
            Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
            String query = "SELECT * FROM log";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Log log = new Log();
                log.setId(resultSet.getInt("id"));
                log.setUsername(resultSet.getString("username"));
                log.setAction(resultSet.getString("action"));
                log.setProfit(resultSet.getFloat("profit"));
                log.setAll(resultSet.getFloat("all"));
                logs.add(log);
            }
            for (Log log: logs) {
                System.out.println(log.toString());
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}