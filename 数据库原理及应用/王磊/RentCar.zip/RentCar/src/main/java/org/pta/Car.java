package org.pta;

import java.util.Scanner;

//轿车
public class Car extends Vehicle{//轿车
    private int id;
    private String type;//型号

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Car{" +
                "id=" + id +",vehicleLd='" + getVehicleLd() + '\'' +
                ", brand='" + getBrand() + '\'' +
                ", perRend=" + getPerRend()+
                ", type='" + type + '\'' +
                '}';
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public float calRent(int days) {
        float rent = 0;
        if (days >= 0 && days < 7) {
            rent =  (float) (getPerRend() * days);
        }  else if (days >= 7 && days < 30) {
            rent =  (float) (getPerRend() * days * 0.9);
        } else if (days >= 30 && days < 150) {
            rent =  (float) (getPerRend() * days * 0.8);
        } else if (days >= 150) {
            rent =  (float) (getPerRend() * days * 0.7);
        }
        return rent;
    }

    @Override
    public void menu(String username) {
        UserManager userManager = new UserManager("jdbc:mysql://127.0.0.1:3306/crs", "root", "2781307050.wl");
        CarManager carManager = new CarManager("jdbc:mysql://127.0.0.1:3306/crs", "root", "2781307050.wl");
        carManager.selectCar();
        System.out.println("请选择你所要租赁的车辆id：");
        Scanner sc = new Scanner(System.in);
        int id = sc.nextInt();
        Car car = carManager.selectCarById(id);
        System.out.println("请选择你所要租赁的天数：");
        int days = sc.nextInt();
        float v = car.calRent(days);
        if (userManager.selectBalance(username)>v) {
            Vehicle vehicle = new Vehicle();
            System.out.println("租赁成功!");
            vehicle.addMoney(username,"租赁大巴"+car.toString(),v);
            userManager.subMoney(username,v);
        }else System.out.println("余额不足，请充值！");
//        System.out.println("1、宝马    2、别克");
//        System.out.println("请选择你要租赁的轿车品牌：");
//        Scanner sc = new Scanner(System.in);
//        int i = sc.nextInt();
//        if (i == 1) {
//            System.out.println("1、550i  2、X6");
//            System.out.println("请选择你要租赁的轿车型号");
//            int j = sc.nextInt();
//            if (j==1){
//                setPerRend(600);
//                System.out.println("请输入您要租赁的天数：");
//                float v = calRent(sc.nextInt());
//                setVehicleLd("京CNY3284");
//                System.out.println("分配给您的车牌号是："+getVehicleLd());
//                System.out.println("您需要支付的租赁费用是："+v+"元");
//            }
//            else if (j==2){
//                setPerRend(800);
//                System.out.println("请输入您要租赁的天数：");
//                float v = calRent(sc.nextInt());
//                setVehicleLd("京NY28588");
//                System.out.println("分配给您的车牌号是："+getVehicleLd());
//                System.out.println("您需要支付的租赁费用是："+v+"元");
//            }
//        }else if (i == 2) {
//            System.out.println("1、林荫大道  2、GL8");
//            System.out.println("请选择你要租赁的轿车型号");
//            int j = sc.nextInt();
//            if (j==1){
//                setPerRend(300);
//                System.out.println("请输入您要租赁的天数：");
//                float v = calRent(sc.nextInt());
//                setVehicleLd("京NT37465");
//                System.out.println("分配给您的车牌号是："+getVehicleLd());
//                System.out.println("您需要支付的租赁费用是："+v+"元");
//            }
//            else if (j==2){
//                setPerRend(600);
//                System.out.println("请输入您要租赁的天数：");
//                float v = calRent(sc.nextInt());
//                setVehicleLd("京NT96968");
//                System.out.println("分配给您的车牌号是："+getVehicleLd());
//                System.out.println("您需要支付的租赁费用是："+v+"元");
//            }
        }
}
