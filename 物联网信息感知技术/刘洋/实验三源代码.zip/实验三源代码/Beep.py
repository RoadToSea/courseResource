from config import *
import RPi.GPIO as GPIO
import time

class Beep:
    def __init__(self,pin):
        self.pin=pin
        GPIO.setup(self.pin, GPIO.OUT)

    def beepCycle(self,delay,num):
        for i in range(num):
            GPIO.output(self.pin, GPIO.HIGH)
            time.sleep(delay)
            GPIO.output(self.pin, GPIO.LOW)
            time.sleep(delay)
    
    def beepOn(self):
       GPIO.output(self.pin, GPIO.HIGH) 

    def beepOff(self):
        GPIO.output(self.pin, GPIO.LOW)

    def clean(self):
        GPIO.cleanup()


