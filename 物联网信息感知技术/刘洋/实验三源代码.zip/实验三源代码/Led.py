from config import *
import RPi.GPIO as GPIO
import time
import pwm

class Led:
    def __init__(self,pin):
        self.pin = pin
        GPIO.setup(self.pin,GPIO.OUT)
        self.LedPWM = pwm.MyPWM(pin,500)

    def Blink(self,delay,times):
        for i in range(0,times):
            GPIO.output(self.pin,GPIO.HIGH)
            time.sleep(delay)
            GPIO.output(self.pin, GPIO.LOW)
            time.sleep(delay)
    
    def Increase(self,delay,stage):
        for i in range(0,100,stage):
            self.LedPWM.setPwm(i)
            time.sleep(delay)

    def Decrease(self,delay,stage):
        for i in range(100,0,-stage):
            self.LedPWM.setPwm(i)
            time.sleep(delay)

    def clean(self):
        GPIO.cleanup()
