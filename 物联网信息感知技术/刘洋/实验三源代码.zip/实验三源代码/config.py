import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)


GPIO_LED = 12
GPIO_BEEP = 29
GPIO_PHASE_A = 32
GPIO_PHASE_B = 36
GPIO_PHASE_C = 38
GPIO_PHASE_D = 40

