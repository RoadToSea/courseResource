from Beep import *
from Led import *
from  config import *
from stepmotor import Stepping_motor
import threading

if __name__ == "__main__":
    led = Led(GPIO_LED)
    beep = Beep(GPIO_BEEP)
    motor = Stepping_motor((GPIO_PHASE_A,GPIO_PHASE_B,GPIO_PHASE_C,GPIO_PHASE_D))
    
    ledThread = threading.Thread(target=led.Increase, args=(1, 5))
    beepThread = threading.Thread(target=beep.beepCycle, args=(0.5,6))
    motorThread = threading.Thread(target=motor.rotate, args=(90, "forward"))
    motorThread.start()
    ledThread.start()
    beepThread.start()

     # 等待所有线程执行完成
    ledThread.join()
    beepThread.join()
    motorThread.join()
    


