from Bh1750 import *
from water import *
import threading


waterLevel = water_level(0,3.3,10,48)
light = Bh1750(0x23)

def waterCollect():
    while True:
        ret = light.measure()
        print(f"当前光照强度是:{ret}")
        time.sleep(1.5)

def lightCollect():
    while True:
        level,volt = waterLevel.read(0)
        print('电压：{:.1f} V, 液面：{:.1f} cm'.format(volt, level))
        time.sleep(1)

# 创建线程
light_thread = threading.Thread(target=lightCollect)
liquid_thread = threading.Thread(target=waterCollect)

light_thread.start()
liquid_thread.start()

light_thread.join()
liquid_thread.join()