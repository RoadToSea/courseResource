from Beep import *
from Led import *
from  config import *
from stepmotor import Stepping_motor
import threading
from water import *
from Bh1750 import *
from Temperature import *
from task import task



if __name__ == "__main__":
    
    
    tasks = task()
    #创建线程
    detectionTask = threading.Thread(target=tasks.detection)
    ledTask = threading.Thread(target=tasks.controlLED)
    waterTask = threading.Thread(target=tasks.controlWater)
    tempTask = threading.Thread(target=tasks.controlHeater)
    #开启线程
    detectionTask.start()
    ledTask.start()
    waterTask.start()   
    tempTask.start()
    #等待线程结束
    detectionTask.join()
    ledTask.join()
    waterTask.join()
    tempTask.join()

    


