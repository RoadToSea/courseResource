from Beep import *
from Led import *
from  config import *
from stepmotor import Stepping_motor
import threading
from water import *
from Bh1750 import *
from Heater import *
from Temperature import *
from alilinkdata import PubSub


# ledFlag = 0
# waterFlag=0
# tempFlag = 0

# lightCritical = 100.0
# waterCritical = [3.0,6.0]
# tempCritical = 30.0


class task:
    def __init__(self):
        self.ledFlag = 0
        self.waterFlag=0
        self.tempFlag = 0
        self.lightCritical = 100.0
        self.waterCritical = [3.0,6.0]
        self.tempCritical = 28.0
        self.light = Bh1750(BH1750ADDR)
        self.water = water_level(0,3.3,10,48)
        self.temp = DS18B20()
        self.led = Led(GPIO_LED)
        self.beep = Beep(GPIO_BEEP)
        self.motor = Stepping_motor((GPIO_PHASE_A,GPIO_PHASE_B,GPIO_PHASE_C,GPIO_PHASE_D))
        self.heater = Heater()
        self.aLiHelper = PubSub(ProductKey,DeviceName,DeviceSecret,TOPIC)
    def controlLED(self):
        while 1:
            if self.ledFlag ==0 :
                self.led.LEDOFF()
            else:
                self.led.LEDON()
            time.sleep(0.3)
    def controlWater(self):
        while 1:
            if self.waterFlag == 1:
                self.motor.motorON()
            else:
                self.motor.motorOFF()
            time.sleep(0.3)
                

    def controlHeater(self):
        while 1:
            if self.tempFlag ==1:
                self.heater.Heater_ON()
            else:
                self.heater.Heater_OFF()
        time.sleep(0.3)

    def detection(self):
        while 1:
            waterVal = self.water.read(0)
            lightVal = self.light.measure()
            tempVal = self.temp.read_temp()
            if waterVal<self.waterCritical[0]:
                self.waterFlag = 1
            elif  waterVal>self.waterCritical[1]:
                self.waterFlag =0
            if lightVal<self.lightCritical:
                self.ledFlag = 1
            elif lightVal>self.lightCritical:
                self.ledFlag =0
            if tempVal<self.tempCritical:
                self.tempFlag = 1
            elif tempVal>self.tempCritical :
                self.tempFlag = 0
            self.aLiHelper.pub(lightVal,waterVal,tempVal,self.ledFlag,self.waterFlag,self.tempFlag)
            print(f"水位: {waterVal} 光照: {lightVal}  温度: {tempVal} ")
            print(f"水位阈值: {self.waterCritical} 光照阈值: {self.lightCritical}  温度阈值: {self.tempCritical} ") 
            print(f"水位标志: {self.waterFlag} 光照标志: {self.ledFlag }  温度标志: {self.tempFlag } ")
            print("-"*40)
            time.sleep(2)

            
