#from config import *
import smbus2 as smbus
import time

BH1750ADDR=0x23


class Bh1750:
    def __init__(self, addr):
        # BH1750地址
        self. ADDR = addr
        # 控制字
        self. PWR_OFF = 0x00 # 关机
        self. PWR_ON = 0x01 # 开机
        self. RESET = 0x07 # 重置
        self. CHRES = 0x10 # 持续高分辨率检测
        self. CHRES2 = 0x11 # 持续高分辨率模式2检测
        self. CLHRES = 0x13 # 持续低分辨率检测
        self. THRES = 0x20 # 一次高分辨率
        self. THRES2 = 0x21# 一次高分辨率模式2
        self. TLRES = 0x23 # 一次分辨率
        self. SEN100H = 0x42 # 灵敏度100%,高位
        self. SEN100L = 0X65 # 灵敏度100%, 低位
        self. SEN50H = 0x44 # 50%
        self. SEN50L = 0x6A # 50%
        self. SEN200H = 0x41 # 200%
        self. SEN200L = 0x73 # 200%
        # 初始化
        self. bus = smbus.SMBus(1)
        self. bus. write_byte( self. ADDR, self. PWR_ON)
        self. bus. write_byte( self. ADDR, self. RESET)
        self. bus. write_byte( self. ADDR, self. SEN100H)
        self. bus. write_byte( self. ADDR, self. SEN100L)
        self. bus. write_byte( self. ADDR, self. PWR_OFF)

    def measure(self):
        #一次测量
        self.bus.write_byte(self.ADDR, self.PWR_ON)
        self.bus.write_byte(self.ADDR, self. THRES2)
        time.sleep(0.2)
        res = self.bus. read_word_data(self.ADDR, 0)
        self.bus.write_byte(self.ADDR, self.PWR_OFF)
        #数据转换
        res =((res >> 8) & 0xff)| (res << 8 )&0xff00
        res = round(res /(2 * 1.2), 2)
        return res



