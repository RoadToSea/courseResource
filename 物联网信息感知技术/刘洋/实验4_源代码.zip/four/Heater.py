import RPi.GPIO as GPIO
from config import *


class Heater:
    def __init__(self):
        self.pin = GPIO_Heater
        GPIO.setup(self.pin,GPIO.OUT)
        GPIO.output(self.pin,GPIO.HIGH)

    def Heater_ON(self):
        GPIO.output(self.pin,GPIO.LOW)

    def Heater_OFF(self):
        GPIO.output(self.pin,GPIO.HIGH)