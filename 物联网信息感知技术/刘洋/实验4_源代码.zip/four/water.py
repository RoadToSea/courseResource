import spidev
import time

class water_level:
    def __init__(self,channel,refVolt,resolution,range):
        self.channel = channel # ADC模拟信号输入通道
        self.refVolt = refVolt # ADC参考电压
        self.range = range # 液位传感器测量范围
        self.resolution = resolution # ADC分辨率
        self.spi = spidev.SpiDev() # 实例化spi
        self.spi.open(0, 0) # 连接spi-decv0.0
        self.spi.max_speed_hz = 1350000 # 设置spi通信速
    def __getMcp3008(self):
        '''
        读取ADC转换得到的数字量
        channel: ADC通道，比如0表示CH0
        return: data,ADC转换结果，10位
        '''
        adc = self.spi.xfer2([1, (8 + self.channel) << 4, 0]) # spi传输
        data = ((adc[1] & 3) << 8) + adc[2] # 根据ADC分辨率调整
        return data
    def __toVolt(self,data):
        '''将ADC数字量转换为电压值'''
        max_adc = 2**self.resolution - 1  # 计算ADC的最大值，10位的最大值是1023
        volts = (data / max_adc) * self.refVolt  # 计算电压值
        return volts

    def __toLevel(self,volts):
        '''将电压值转换为液位高度'''
        # 假设液位传感器输出电压是线性对应液位高度
        # 电压范围 0V -> refVolt, 液位范围 0cm -> range cm
        level = (volts / self.refVolt) * self.range  # 液位高度，单位cm
        return level

    def read(self,channel):
        data = self.__getMcp3008()
        volt = self.__toVolt(data)#供调试
        level =self.__toLevel(volt)
        return level
    
# if __name__ == '__main__':
#     waterLevel = water_level(0,3.3,10,48)
#     while True:
#         level = waterLevel.read(0)
#         print(f'液面: {level}')
#         time.sleep(1)