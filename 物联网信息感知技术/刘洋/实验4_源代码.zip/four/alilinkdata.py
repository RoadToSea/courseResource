import  time
from config import *
import aliLink 
import mqttd 

class PubSub:
    def  __init__(self,ProductKey,DeviceName,DeviceSecret,topic):
        self.ProductKey = ProductKey
        self.DeviceName = DeviceName
        self.DeviceSecret = DeviceSecret
        self.topic = topic

        Server, ClientId, userName, Password = aliLink.linkiot(DeviceName, ProductKey, DeviceSecret) 
        self.mqtt = mqttd.MQTT(Server, ClientId, userName, Password) 
        self.mqtt.begin(self.__on_message, self.__on_connect)

       
    def  __on_message(self, client, userdata, msg):
        pass

    def __on_connect(self, client, userdata, flags, rc):
        ''' :param client: the client instance for this callback
            :param userdata: the private user data as set in Client()
            :param flags: response flags sent by the broker
            :param rc: the connection result
            0: Connection successful
            1: Connection refused - incorrect protocol version
            2: Connection refused - invalid client identifier
            3: Connection refused - server unavailable
            4: Connection refused - bad username or pa
        '''
        if rc == 0:
            print("Connected successful!")
        else:
            print(f"Connected refused with result code: {rc}")

    def pub(self,light,waterLevel,temperature,ledState,tapState,temperature_heater):
        msg = {
            'WaterTemperature':temperature,
            'Light':light,
            'Liquid_level':waterLevel,
            'Water_temperature_heater':temperature_heater,
            'Stepper_motors':tapState,
            'Led':ledState
        }

        JsonMsg = aliLink.Alink(msg)
        self.mqtt.push(self.topic,JsonMsg)
        # print(f'msg to aliCloud:{msg}')

# if __name__=="__main__":
#    aLiHelper = PubSub(ProductKey,DeviceName,DeviceSecret,TOPIC)
#    while True:
#         aLiHelper.pub(23,12,34.0,1,1,1)
#         time.sleep(2)

