import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)

GPIO_Heater = 35
GPIO_LED = 12
GPIO_BEEP = 29
GPIO_PHASE_A = 32
GPIO_PHASE_B = 36
GPIO_PHASE_C = 38
GPIO_PHASE_D = 40

TOPIC = "/sys/k1uf7xbGXqm/fish_tank/thing/event/property/post"
ProductKey = "k1uf7xbGXqm"
DeviceName = "fish_tank"
DeviceSecret = "0460734e2940cc2a501a4d5cabf2e518"

            # 'WaterTemperature' : temperature,
            # 'led' : ledState,
            # 'Stepper_motors': tapState,
            # 'Water_temperature_heater':temperature_heater
            # 'Light' : light,
            # 'Liquid_level': waterLevel,
