import RPi.GPIO as GPIO
import config


class MyPWM:
    def __init__(self,pin,frequency) -> None:
        self.pin = pin
        GPIO.setup(pin,GPIO.OUT)
        self.pwm = GPIO.PWM(self.pin,frequency)

    def setPwm(self,value):
        self.pwm.start(value)

    def stopPwm(self):
        self.pwm.stop()