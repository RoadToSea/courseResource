import time
from config import *
import RPi.GPIO as GPIO

class Stepping_motor :
    def __init__(self,pin):# 为(GPID_PHASE_A,GPIO_PHASE_B,GPIO_PHASE_C,GPIO_PHASE_D)元组
        self.pulse = [(1,0,0,0),
                      (1,1,0,0),
                      (0,1,0,0),
                      (0,1,1,0),
                      (0,0,1,0),
                      (0,0,1,1),
                      (0,0,0,1),
                      (1,0,0,1)]
        self.phaseA, self.phaseB, self.phaseC, self.phaseD = pin
        self.stepPerDegree = 4096/360
        self.Flag=0
        GPIO.setup(self.phaseA,GPIO.OUT)  # 设置GPI0 pin为输出
        GPIO.setup(self.phaseB,GPIO.OUT)
        GPIO.setup(self.phaseC,GPIO.OUT)
        GPIO.setup(self.phaseD,GPIO.OUT)

    def __set_step(self,pulseIn):
        p1,p2,p3,p4 = pulseIn
        GPIO.output(self.phaseA,p1)
        GPIO.output(self.phaseB, p2)
        GPIO.output(self.phaseC, p3)
        GPIO.output(self.phaseD, p4)

    def motorON(self,direction ="back"):
        delay = 0.001
        self.Flag = 1
        for i in range(100):
            if self.Flag == 1:
                if direction =="back":
                    for j in range(len(self.pulse)):
                        self.__set_step(self.pulse[j])
                        time.sleep(delay)
                elif direction == "forward":
                    for j in range(len(self.pulse) - 1, -1, -1):
                        self.__set_step(self.pulse[j])
                        time.sleep(delay)
    def motorOFF(self):
        self.Flag = 0
        

    # def rotate(self,degree,direction="forward"):
    #     steps= degree*self.stepPerDegree
    #     step=0
    #     delay = 0
    #     while step<steps:
    #         if direction =="back":
    #             for j in range(len(self.pulse)):
    #                 self.__set_step(self.pulse[j])
    #                 step+=1
    #                 time.sleep(delay)
    #         elif direction == "forward":
    #             for j in range(len(self.pulse) - 1, -1, -1):
    #                 self.__set_step(self.pulse[j])
    #                 step+=1
    #                 time.sleep(delay)

    def rotate(self,direction=0,):
        delay = 0.001
        while True:
            if direction ==1:
                for j in range(len(self.pulse)):
                    self.__set_step(self.pulse[j])
                    time.sleep(delay)
            else:
                for j in range(len(self.pulse) - 1, -1, -1):
                    self.__set_step(self.pulse[j])
                    time.sleep(delay)

    def clean(self):
        GPIO.cleanup()

