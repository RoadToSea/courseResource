import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BOARD)
GPIO.setwarnings(False)


GPIO_LED = 7
GPIO_BEEP = 40

