from config import *
import RPi.GPIO as GPIO
import time

class Led:
    def __init__(self,pin):
        self.pin = pin
        GPIO.setup(self.pin,GPIO.OUT)

    def __oneBlink(self):

        GPIO.output(self.pin,GPIO.HIGH)
        time.sleep(0.4)
        GPIO.output(self.pin, GPIO.LOW)
        time.sleep(0.6)
    def blinks(self):
        for i in range(50):
            self.__oneBlink()

    def clean(self):
        GPIO.cleanup()


if __name__ == '__main__':
    led = Led(GPIO_LED)
    led.blinks()
    led.clean()
