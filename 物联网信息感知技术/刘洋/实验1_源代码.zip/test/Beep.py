from config import *
import RPi.GPIO as GPIO
import time

class Beep:
    def __init__(self,pin):
        self.pin=pin
        GPIO.setup(self.pin, GPIO.OUT)

    def upbeep(self,num):
        for i in range(num):
            GPIO.output(self.pin, GPIO.HIGH)
            time.sleep(0.1)
            GPIO.output(self.pin, GPIO.LOW)
            time.sleep(0.9)

    def clean(self):
        GPIO.cleanup()

if __name__ == '__main__':
    beep = Beep(GPIO_BEEP)
    beep.upbeep(50)
    beep.clean()
