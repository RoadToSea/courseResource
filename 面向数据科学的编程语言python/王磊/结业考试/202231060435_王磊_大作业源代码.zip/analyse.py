import pandas as pd
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt

# 设置全局字体
plt.rcParams['font.sans-serif'] = ['SimHei']  # 使用黑体作为全局字体
# 从CSV文件加载数据到DataFrame
data = pd.read_csv('Mall_Customers.csv')

# 提取用于聚类的相关特征
X = data.iloc[:, [2, 3, 4]].values  # 我们选择年龄、年收入、消费评分这三列作为特征

# 第一次展示所有样本的3D散点图
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')
scatter = ax.scatter(X[:, 0], X[:, 1], X[:, 2], s=50)
ax.set_xlabel('年龄')
ax.set_ylabel('年收入（k$）')
ax.set_zlabel('消费评分（1-100）')
ax.set_title('原始数据样本')

plt.show()

# 自定义均值漂移聚类算法
def custom_meanshift(X, bandwidth=2):
    centroids = X
    while True:
        new_centroids = []
        for centroid in centroids:
            in_bandwidth = [x for x in X if np.linalg.norm(x - centroid) <= bandwidth]
            new_centroid = np.mean(in_bandwidth, axis=0)
            new_centroids.append(new_centroid)
        if np.allclose(centroids, new_centroids):
            break
        centroids = new_centroids
    return np.array(centroids)

# 使用自定义均值漂移聚类
centroids = custom_meanshift(X)

# 根据聚类中心计算样本所属类别
labels = []
for x in X:
    distances = [np.linalg.norm(x - centroid) for centroid in centroids]
    label = np.argmin(distances)
    labels.append(label)
labels = np.array(labels)

# 确保聚类为5类
unique_labels = np.unique(labels)
num_clusters = len(unique_labels)
if num_clusters > 4:
    # 如果聚类结果多于5类，则将距离最近的聚类中心合并，直到聚类数为5类
    while num_clusters > 4:
        min_distance = float('inf')
        merge_indices = None
        for i in range(num_clusters):
            for j in range(i + 1, num_clusters):
                distance = np.linalg.norm(centroids[i] - centroids[j])
                if distance < min_distance:
                    min_distance = distance
                    merge_indices = (i, j)
        centroids[merge_indices[0]] = (centroids[merge_indices[0]] + centroids[merge_indices[1]]) / 2
        centroids = np.delete(centroids, merge_indices[1], axis=0)
        # 更新标签
        labels = np.argmin(np.linalg.norm(X[:, None] - centroids, axis=2), axis=1)
        unique_labels = np.unique(labels)
        num_clusters = len(unique_labels)

# 第二次展示分类结果的3D散点图和聚类中心
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')
scatter = ax.scatter(X[:, 0], X[:, 1], X[:, 2], c=labels, cmap='viridis', s=50, label='样本')
ax.scatter(centroids[:, 0], centroids[:, 1], centroids[:, 2], c='red', marker='X', s=200, label='聚类中心')
ax.set_xlabel('年龄')
ax.set_ylabel('年收入（k$）')
ax.set_zlabel('消费评分（1-100）')
ax.set_title('自定义均值漂移聚类结果')

# 添加图例
legend1 = ax.legend(*scatter.legend_elements(),
                    loc="upper left", title="聚类")
ax.add_artist(legend1)
ax.legend()

plt.show()
