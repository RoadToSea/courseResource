import pandas as pd
import jieba
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import re

# 读取 CSV 文件为 DataFrame
df = pd.read_csv('./douban_comments.csv')

# 统计数据中各列的缺失值总数和空白总数
missing_values = df.isnull().sum()
blank_values = df.applymap(lambda x: str(x).strip() == '').sum()

print("缺失值:")
print(missing_values)
print("\n空白总数:")
print(blank_values)

# 分析评分分布
ratings_counts = df['评分'].value_counts().sort_index()

title = df['电影名称'].iloc[0]
print(title)

# 分析评论内容
comments_text = ' '.join(df['评论内容'])
# 使用 jieba 进行中文分词
words = ' '.join(jieba.cut(comments_text))

# 点赞数列数据处理
# 过滤点赞数列中的缺失值和空白
filtered_likes = df['点赞数'].dropna().apply(lambda x: str(x).strip())
# 找出点赞数最大值对应的数据记录
most_liked_comment = df.loc[df['点赞数'].idxmax()]

print("\n最受喜欢的评论:")
print(most_liked_comment)

# 相关分析
# 过滤评分与点赞数列中的缺失值和空白评分
filtered_data = df.dropna(subset=['评分', '点赞数']).applymap(lambda x: str(x).strip())
# 将评分列转换为数值类型
rating_mapping = {'力荐': 5, '推荐': 4, '还行': 3, '较差': 2, '很差': 1}
filtered_data['评分'] = filtered_data['评分'].map(rating_mapping)
# 计算评分与点赞数之间的相关系数
correlation = filtered_data['评分'].astype(float).corr(filtered_data['点赞数'].astype(float))
print("\n评分与点赞数之间的相关系数:", correlation)

# 评论内容分析
# 过滤评论内容列中的缺失值和空白
filtered_comments = df['评论内容'].dropna().apply(lambda x: str(x).strip())

# 使用正则表达式去除标点符号
comments_text_no_punct = re.sub(r'[^\w\s]', '', comments_text)

# 使用 jieba 分词，并过滤掉长度小于2的词和标点符号
words_filtered = [word for word in jieba.cut(comments_text_no_punct) if len(word) >= 2]

# 计算词频
word_freq = pd.Series(words_filtered).value_counts().head(3)
print("\n评分最高的三个词:")
print(word_freq)

# 创建新的图形，并绘制柱状图和词云图
plt.figure(figsize=(15, 6))

# 绘制评分柱状图
plt.subplot(1, 2, 1)
ratings_counts.plot(kind='bar', color='skyblue')
plt.title(f'{title}评分分布', fontproperties='SimHei')  # 手动指定中文字体
plt.xlabel('评分', fontproperties='SimHei')  # 手动指定中文字体
plt.ylabel('评论数量', fontproperties='SimHei')  # 手动指定中文字体
plt.xticks(rotation=0, fontproperties='SimHei')  # 手动指定中文字体

# 绘制评论内容词云图
plt.subplot(1, 2, 2)
wordcloud = WordCloud(font_path='simhei.ttf', background_color='white', width=800, height=400).generate(words)
plt.imshow(wordcloud, interpolation='bilinear')
plt.title(f'{title}评论词云图', fontproperties='SimHei')  # 手动指定中文字体
plt.axis('off')

plt.tight_layout()  # 自动调整子图间距
plt.show()
