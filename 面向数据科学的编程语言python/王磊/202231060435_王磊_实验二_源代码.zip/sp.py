import csv

import requests
from bs4 import BeautifulSoup

fp = open('./douban_comments.csv', 'w', encoding='utf-8')
writer = csv.writer(fp)
writer.writerow(['电影名称', '用户名', '评分', '评论时间', '点赞数', '评论内容'])


def fetch_douban_comments(movie_id, page=0):
    url = f"https://movie.douban.com/subject/{movie_id}/comments?start={page * 20}&limit=20&status=P&sort=new_score"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Safari/537.36"
    }
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, "html.parser")
        comment_items = soup.find_all("div", class_="comment-item")
        title = soup.find("title").get_text().strip()
        title = title.replace("电影名称", "").replace("短评", "")
        for item in comment_items:
            username = item.find("span", class_="comment-info").find("a").get_text().strip()
            rating = item.find("span", class_="rating")["title"] if item.find("span", class_="rating") else "无评分"
            timestamp = item.find("span", class_="comment-time").get("title")
            vote = item.find("span", class_="votes").get_text()
            content = item.find("span", class_="short").get_text().strip()
            print(f"用户名: {username}")
            print(f"评分: {rating}")
            print(f"时间: {timestamp}")
            print(f"投票数: {vote}")
            print(f"内容: {content}\n")
            writer.writerow([title, username, rating, timestamp, vote, content])
    else:
        print("Failed to fetch comments.")


# Example usage:
for i in range(0, 10):
    fetch_douban_comments("1292052", page=i)  # Replace "1292052" with the ID of the movie you want to fetch comments
fp.close()
