from 图书管理系统.data_utils import *

while True:  # while 循环
    print("-" * 60)     # * 复制容器里面的数据
    print("1：图书添加  2：图书删除 3：图书位置修改 \n "
          "4：图书借出  5：图书还回 6：图书信息查看  7：退出系统")
    func_code = input("请您输入需要使用的功能：")
    print("-" * 60)

    if func_code == "1":  # func_code 需要注意输入的数据类型
        add_book()        # 函数的调用
    elif func_code == "2":
        del_book()
    elif func_code == "3":
        modify_book()
    elif func_code == "4":
        lend_book()
    elif func_code == "5":
        give_back()
    elif func_code == "6":
        select_book()
    elif func_code == '7':
        print("系统正在退出中...")
        exit()        # 循环里面的关键字  只能在循环里面使用
    else:
        print("输入的选项id无效！")

