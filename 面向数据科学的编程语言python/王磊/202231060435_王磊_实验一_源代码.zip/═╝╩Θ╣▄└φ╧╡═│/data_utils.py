import json

# books_dict = {}
fr = open("Books.txt", "r", encoding="UTf-8-sig")
book_data = fr.read()
books_dict = json.loads(book_data)


def add_book():
    """增加图书信息"""
    book_id = input("请输入书的id：")  # key
    if book_id not in books_dict:
        book_name = input("请输入书的名称：")  # value
        book_author = input("请输入书的作者名称:")
        book_position = input("请输入书的位置：")  # value
        is_lend = False  # 是否借出
        book_type = input("请输入书的类型：")

        books_dict[book_id] = {"书名": book_name,
                               "作者": book_author,
                               "书的位置": book_position,
                               "是否借出": is_lend,
                               "类型": book_type}  # 将输入的图书信息存储到字典
        books_dict1 = json.dumps(books_dict, ensure_ascii=False)
        fw = open("Books.txt", "w", encoding="UTf-8-sig")
        fw.write(books_dict1)
        fw.flush()
        print(f"数据添加完成：:{books_dict[book_id]}")  # 显示添加数据后的信息
    else:
        print("书籍已存在，请勿重复添加！")


def del_book():
    """删除图书信息"""
    book_id = input("请输入书的id：")
    if book_id in books_dict:
        book_info = books_dict[book_id]  # 通过key获取字典的数据 字典数据的获取
        del books_dict[book_id]  # 删除字典里面指定key数据  字典
        books_dict1 = json.dumps(books_dict, ensure_ascii=False)
        fw = open("Books.txt", "w", encoding="UTf-8-sig")
        fw.write(books_dict1)
        fw.flush()
        print(f"删除图书：{book_id}:{book_info}")
    else:
        print("书籍不存在或已被删除！")


def select_book():  # 查找详细的图书 查找已经借出的图书 查看所有的图书信息
    """查找图书的信息"""
    print("1：查找详细的图书 2：查找已经借出的图书 3：查看所有的图书信息")
    sub_code = input("请您输入需要使用的功能：")

    if sub_code == "1":
        book_id = input("请输入书的id：")
        if book_id in books_dict:
            print(books_dict[book_id])      # 通过key获取字典key相关的数据
        else:
            print("未找到相关书籍")

    elif sub_code == "2":
        for i in books_dict.items():  # 字典课程 字典操作方法
            if i[1]['是否借出'] == '已借出':  # 筛选字典的数据 i[1] 字符串的操作 字符串的索引
                print(i)

    elif sub_code == "3":
        for i in books_dict.items():
            print(i)


def modify_book():
    """图书位置的修改"""  # 字典数据的修改
    book_id = input("请输入书的id：")  # key
    book_position = input("请输入书存放新的位置：")
    books_dict[book_id]['书的位置'] = book_position
    books_dict1 = json.dumps(books_dict, ensure_ascii=False)
    fw = open("Books.txt", "w", encoding="UTf-8-sig")
    fw.write(books_dict1)
    fw.flush()
    print(f"修改后的数据：{book_id}：{books_dict[book_id]}")


def lend_book():
    """图书的借出"""
    book_id = input("请输入书的id：\n")
    if books_dict[book_id]["是否借出"] == '未借出':
        books_dict[book_id]["是否借出"] = '已借出'
        books_dict1 = json.dumps(books_dict, ensure_ascii=False)
        fw = open("Books.txt", "w", encoding="UTf-8-sig")
        fw.write(books_dict1)
        fw.flush()
        print("借书成功！")
    else:
        print("书已借出！")


def give_back():
    """图书的还回"""
    book_id = input("请输入书的id：\n")
    if books_dict[book_id]["是否借出"] == '已借出':
        books_dict[book_id]["是否借出"] = '未借出'
        books_dict1 = json.dumps(books_dict, ensure_ascii=False)
        fw = open("Books.txt", "w", encoding="UTf-8-sig")
        fw.write(books_dict1)
        fw.flush()
        print("还书成功！")
    else:
        print("书已归还，请勿重复操作！")
