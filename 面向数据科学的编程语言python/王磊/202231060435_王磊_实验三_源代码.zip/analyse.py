# 1、数据预处理
# 读取 lianjia.xls 数据，存储到 dataframe 对象，完成以下内容：
# 1) 提取['name','decorate','area', 'floor'，'total_floor'，'rentFee']共 6 列数据，用于后续机器学习
# 2) 房屋面积 area 是回归分析的核心参数，不能有缺失值，过滤 area 列缺失值
# 3) 查看'decorate'缺失值，并将缺失值填充为'非精装'；
# 4) 查看'floor'缺失值，并将:缺失值填充为'低楼层'；
# 5) 查看’name’列楼盘信息，提取特定楼盘数据共后续使用（学号末尾奇数提取’ 誉峰三
# 期’数据，偶数提取’招商玺荟’和"润富国际公寓"数据；
# 6) 特征编码：'decorate'列，'非精装'编码为 0,'精装'编码为 1；'floor'列，'低楼层'编码为
# 0,'中楼层'编码为 1，'高楼层'编码为 2
# 7) 'rentFee'列除以 1000，单位为千元
# 2、数据集准备
# 1) 完成数据归一化
# 2) 数据集拆分为训练集和测试集，测试集占比 30%
# 3、单变量回归分析
# 构建数据集：以'area'列数据为特征 ,'rentFee'列为标注信息，进行线性回归分析，分别
# 计算并打印训练和测试误差
# 4、多变量回归分析
# 构建数据集：以['area', 'decorate', 'floor'，'total_floor']共 4 列数据为特征 ,'rentFee'列为
# 标注信息，特征数据经归一化处理后，进行线性回归分析，计算并打印训练误差和测
# 试误差之和，对比单变量和多变量分析结果
# 5、新样本预测
# 读取”new_house.xls” 文件中的新样本，根据学号选择对应数据，使用回归模型预测并打印
# 新样本的房租。
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error

# 读取Excel文件数据到DataFrame
df = pd.read_excel('lianjia.xlsx')

# 提取指定列数据
df = df[['name', 'decorate', 'area', 'floor', 'total_floor', 'rentFee']]

# 数据预处理
# 过滤缺失值
df = df.dropna(subset=['area'])

# 填充'decorate'列缺失值
df['decorate'] = df['decorate'].fillna('非精装')

# 填充'floor'列缺失值
df['floor'] = df['floor'].fillna('低楼层')

# 查看’name’列楼盘信息，提取特定楼盘数据
df = df[df['name'].str.contains('誉峰三期')]

# 特征编码
df['decorate'] = df['decorate'].map({'非精装': 0, '精装': 1})
df['floor'] = df['floor'].map({'低楼层': 0, '中楼层': 1, '高楼层': 2})

# 'rentFee'列除以1000
df['rentFee'] = df['rentFee'] / 1000


# 完成数据归一化,[0,1]区间内
def normalize(data, *cols):
    data_cp = data.copy()
    for col in cols:
        data_cp[col] = (data_cp[col] - data_cp[col].min()) / (data_cp[col].max() - data_cp[col].min())
    return data_cp


df = normalize(df, 'area', 'decorate', 'floor', 'total_floor')
# 使输出结果对齐
print(df.head())

# 单变量回归分析
X = df[['area']]
X = StandardScaler().fit_transform(X)
y = df['rentFee']
# 数据集拆分为训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
model = LinearRegression()
model.fit(X, y)
print("单变量回归分析结果：")
print('训练误差：', mean_squared_error(y_train, model.predict(X_train)))
print('测试误差：', mean_squared_error(y_test, model.predict(X_test)), '\n')

X_multi = df[['area', 'decorate', 'floor', 'total_floor']]
X_multi = StandardScaler().fit_transform(X_multi)
# 数据集拆分为训练集和测试集
X_train_multi, X_test_multi, y_train_multi, y_test_multi = train_test_split(X_multi, y, test_size=0.3, random_state=42)
model_multi = LinearRegression()
model_multi.fit(X_train_multi, y_train_multi)
y_train_pred = model_multi.predict(X_train_multi)
y_test_pred = model_multi.predict(X_test_multi)
print("多变量回归分析结果：")
print(
    f'训练误差:{mean_squared_error(y_train_multi, y_train_pred)} + 测试误差:{mean_squared_error(y_test_multi, y_test_pred)} '
    f'= {mean_squared_error(y_train_multi, y_train_pred) + mean_squared_error(y_test_multi, y_test_pred)}\n')

# 新样本预测
df_new = pd.read_excel('new_houses.xls')

df_new = df_new[df_new['name'].str.contains('誉峰三期')]
df_new['decorate'] = df_new['decorate'].map({'非精装': 0, '精装': 1})
df_new['floor'] = df_new['floor'].map({'低楼层': 0, '中楼层': 1, '高楼层': 2})

# 使用单变量回归模型预测房租
print("使用单变量回归模型预测房租:")
rentFee = model.predict(StandardScaler().fit_transform(df_new[['area']]))
print(f"{rentFee} 单位：千元 / 月\n")

# 使用多变量回归模型预测房租
print("使用多变量回归模型预测房租:")
rentFee_multi = model_multi.predict(
    StandardScaler().fit_transform(df_new[['area', 'decorate', 'floor', 'total_floor']]))
print(f"{rentFee_multi} 单位：千元 / 月")
