import urllib.request
from time import sleep

from bs4 import BeautifulSoup
from openpyxl import Workbook

# 设置请求头部
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36 SLBrowser/9.0.3.1311 SLBChan/105"
}

# 创建Excel工作簿
wb = Workbook()
ws = wb.active
ws.append(['name', 'decorate', 'check', 'area', 'floor', 'total_floor', 'rentFee'])

for page in range(1, 41):
    url = f"https://cd.lianjia.com/zufang/jinrongcheng/pg{page}rt200600000001/#contentList"
    sleep(1)
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req) as response:
            html = response.read().decode('utf-8')
    except urllib.error.URLError as e:
        print(f"页面 {url} 获取失败：{e.reason}")
        continue

    soup = BeautifulSoup(html, 'html.parser')
    for item in soup.find_all('div', class_='content__list--item'):
        try:
            des = item.find('p', class_='content__list--item--des')
            name_tag = des.find_all('a')[2]
            name = name_tag.get('title').strip() if name_tag else ""
            area_tag = des.find_all('i')[0].next_sibling
            area = area_tag.text.strip().strip("㎡") if area_tag else ""
            floors_tag = des.find('span', class_='hide').find('i').next_sibling
            if floors_tag:
                floors_text = floors_tag.text.strip()
                floor = floors_text.split(' ')[0].strip()
                total_floor = floors_text.split(' ')[-1].strip("（）").strip("层")
            else:
                floor = ""
                total_floor = ""
            oneline = item.find('p', class_='content__list--item--bottom oneline')
            decorate_tag = item.find('i', class_='content__item__tag--decoration')
            decorate = decorate_tag.text.strip() if decorate_tag else ""
            check_tag = oneline.find('i', class_='content__item__tag--gov_certification')
            check = check_tag.text.strip() if check_tag else ""
            rentFee_tag = item.find('span', class_='content__list--item-price')
            rentFee = rentFee_tag.text.strip(" 元/月") if rentFee_tag else ""
            ws.append([name, decorate, check, area, floor, total_floor, rentFee])
            print(f"{name} {decorate} {check} {area} {floor} {total_floor} {rentFee}")
        except Exception as e:
            print(f"爬取失败：{e}")
            continue

    print(f"{page}页爬取完成")
    print("----------------------------------------------------------------------------------------------------------")

# 保存Excel文件
wb.save('lianjia.xlsx')
