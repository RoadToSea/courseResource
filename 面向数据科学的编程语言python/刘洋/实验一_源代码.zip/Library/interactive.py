from bookManager import bookManager 

#查询全部书籍、添加书籍、借阅书籍、归还书籍和退出系统。
info = {1:"查询全部书籍",2:"添加书籍",3:"借阅书籍",4:"归还书籍",5:"储存书籍",6:"退出系统"}


def show(manager):
    print()
    print("请输入编号以操作:")
    for i in range(1,7):
        print(f"{i}: {info[i]}")
    choice = int(input())
    if choice ==1:
        manager.searchBook()
    elif choice ==2 :
        book = manager.conductBook()
        if manager.findBook(book.bookName)==None:
            manager.addBook(book)
        else:
            print("书籍已经存在!")
    elif choice ==3:
        print("请输入书籍名称:")
        bookName = input()
        if manager.findBook(bookName)!=None:
            manager.borrowBook(bookName)
        else:
            print("书籍不存在!")
    elif choice ==4:
        print("请输入书籍名称:")
        bookName = input()
        if manager.findBook(bookName)!=None:
            manager.returnBook(bookName)
        else:
            print("书籍不存在!")
    elif choice ==5:
        manager.storeBook()
    else:
        exit()


if __name__ == "__main__":
    manager = bookManager()
    manager.obtainBook()
    print("欢迎使用图书管理系统")
    while True:
        show(manager)
