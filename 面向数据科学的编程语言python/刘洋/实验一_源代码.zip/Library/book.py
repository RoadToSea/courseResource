
#书籍类:存储每本书籍的书名,作者,借阅状态
class book:
    def __init__(self,name,author,status) -> None:
        self.bookName = name
        self.bookAuthor = author
        self.bookStatus = status

    def showInfo(self):
        if self.bookStatus:
            print("***************************")
            print(f"书名:{self.bookName}\n作者:{self.bookAuthor}\n借阅情况:未被借阅")
            print("***************************")
        else:
            print("***************************")
            print(f"书名:{self.bookName}\n作者:{self.bookAuthor}\n借阅情况:已被借阅")
            print("***************************")



# if __name__ == "__main__":
#     books = book("123","sdd",True)
#     books.showInfo()            