from book import *
import pickle

#查询全部书籍、添加书籍、借阅书籍、归还书籍
class bookManager:
    def __init__(self) -> None:
        self.bookList = []
    
    def conductBook(self):
        print("请输入书名")
        bookName = input()
        print("请输入作者")
        author = input()
        return book(bookName,author,True)

    def findBook(self,bookName):
        for books in self.bookList:
            if books.bookName ==bookName: 
                return books
        return None

    def searchBook(self):
        for books in self.bookList:
            books.showInfo()
    
    def addBook(self,book):
        self.bookList.append(book)

    def borrowBook(self,bookName):
        result = self.findBook(bookName)
        if(result!=None):
            result.bookStatus = False
            print("借阅成功")
        else:
            print("书籍不存在")
        
    def returnBook(self,bookName):
        result = self.findBook(bookName)
        if(result!=None):
            result.bookStatus = True
            print("归还成功")
        else:
            print("书籍不存在")

    def storeBook(self):
        with open(f'Library/bookInfo.txt',"wb") as f:
            pickle.dump(self.bookList,f)
    
    def obtainBook(self):
        with open(f'Library/bookInfo.txt',"rb") as f:
            content = f.readline()
            if content != b'': 
                f.seek(0)
                self.bookList = pickle.load(f)

if __name__ == "__main__":
    book1 = book("book1","sdd",True)
    # book2 = book("book2","ali",False)
    # book3 = book("book3","jack",True)
    manager = bookManager()
    manager.addBook(book1)
    # manager.searchBook() 
    # manager.addBook(book2)
    # manager.addBook(book3)
    # manager.searchBook()
    # manager.borrowBook("book1")
    #manager.storeBook()
    manager.obtainBook()
    manager.searchBook()
    
         