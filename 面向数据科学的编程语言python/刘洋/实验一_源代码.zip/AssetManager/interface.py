from account import Account

#用户交互代码
def user_interaction(core):
    while True:
        print(f"当前您的存款数量:{core.deposit:.1f}")
        print("请选择操作:")
        print("1 - 收入")
        print("2 - 支出")
        print("q - 退出程序")
        choice = input("请输入您的选择 (1 ,2 ,q ):")

        if(choice=="1"):
            income = float(input("请输入收入金额:"))
            core.add_income(income)
        elif(choice == "2"):
            expend = float(input("请输出支出金额:"))
            core.add_expense(expend)
        else:
            break
    core.storeData()  
        

    
