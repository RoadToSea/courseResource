import interface
from account import Account



print("欢迎使用个人财务管理工具! ")
liuyang = Account("liuyang",1001)
interface.user_interaction(liuyang)
print("感谢使用个人财务管理工具,再见! ")

