# 设计账户核心为一个类,以一个对象代表一个用户,分别管理各自的财产和业务逻辑
class Account:
    #如果文件中没有数据,就按照用户输入的数据为对象赋值,否则用文件中的数据覆盖输入数据
    def __init__(self,username="user",deposit=0,filePath = f"./data.txt") -> None:
        self.username = username
        self.deposit = float(deposit)
        self.filePath = filePath
        self.readData()

    #处理收入操作并更新当前存款
    def add_income(self,income):
        self.deposit+=income
        print(f"收入 {income} 已添加。当前存款: {self.deposit}")

    #处理支出操作并更新当前存款
        #1.如果存款充足正常扣款
        #2.如果存款不足提醒用户并不扣款
    def add_expense(self,expend):
        self.deposit-=expend
        if(self.deposit<0):
            print("您已经负债,注意支出,支出失败")
            self.deposit+=expend
        else:
            print(f"支出 {expend} 已扣除。当前存款: {self.deposit}")

    #从文件中读取用户数据
    def readData(self):
        try:
            with open(self.filePath,mode='r',encoding='utf-8') as file:
                data = file.readline()
                userInfo = data.split(':')
                self.username = userInfo[0]
                self.deposit = float(userInfo[1])
        except:
            pass


    def storeData(self):
         #将数据写入文件,下次直接读取
        with open(self.filePath,mode='w',encoding='utf-8') as file:
            file.write(f"{self.username}:{self.deposit}\n")
            file.flush()

    
            