import urllib.request
from bs4 import BeautifulSoup
import pandas as pd
import threading
import queue

def get_html(url):
    headers = {'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0',
               'cookie':"lianjia_uuid=dd8e2275-65ab-4fc2-8cae-6d2eb00d7554; select_city=510100; GUARANTEE_POPUP_SHOW=true; GUARANTEE_BANNER_SHOW=true; login_ucid=2000000446809329; lianjia_token=2.0010954ec947ade7d4013867f810389d5e; lianjia_token_secure=2.0010954ec947ade7d4013867f810389d5e; security_ticket=ERFxRD3lPYfsTcWaJBXNMWVmWeHgOJmcfbXB4po3OuvV5xNvCu0aB6vtiPlwjoj6FYSQZdsw+yQRHpGxHFCL6Lh+3NhyhZikSQULiNtQ4nV/nQAvXYZsyi5yhu/PkZBYN6nF2lbZMhrxaE03JzG4AlOpmYwqGeGH9a6ROZeVsb4=; ftkrc_=52ae4ab0-92d5-4f93-9930-ef1fb8c331f3; lfrc_=625ceb81-d8ae-4d9f-b10f-2fbf18fce433; lianjia_ssid=9a176729-05f7-4caf-8cc9-e1f0c54bdfd4; sensorsdata2015jssdkcross=%7B%22distinct_id%22%3A%221922e08c82d5ab-06b8817e2fd2f3-4c657b58-1350728-1922e08c82e61f%22%2C%22%24device_id%22%3A%221922e08c82d5ab-06b8817e2fd2f3-4c657b58-1350728-1922e08c82e61f%22%2C%22props%22%3A%7B%22%24latest_traffic_source_type%22%3A%22%E8%87%AA%E7%84%B6%E6%90%9C%E7%B4%A2%E6%B5%81%E9%87%8F%22%2C%22%24latest_referrer%22%3A%22https%3A%2F%2Fcn.bing.com%2F%22%2C%22%24latest_referrer_host%22%3A%22cn.bing.com%22%2C%22%24latest_search_keyword%22%3A%22%E6%9C%AA%E5%8F%96%E5%88%B0%E5%80%BC%22%7D%7D; hip=xh2AWTs4ATccX0NBhvDlgGFqyJQ5AwBkRTkskXNDOzDj69VXTqH7R-kCwUQC2WcS_H5PWCTrE1YVciBOF_1nwuiJzq2uDobhPnulg1LTbfIZD6xWXAa3AKfwLv19KKX3kKPBKlRIH5h1fAJqxc-L6f_y2OmSVD8syN_Tp45tckodHGOXCXASISbAeQ%3D%3D; srcid=eyJ0Ijoie1wiZGF0YVwiOlwiNTJlYjc1NjQ2MjY3OGRjZWM1ZmUyOGM3MWJlMWMyNjAxYjFmNjg2MWQ4YjlmYTk1ZWIxNTkzY2U0MTNkZDJlZTNjOTZlODBhODM0MzQ4ODM4OTU2NjQ2NzAxMGI1NDFkMzZkYjU3Yjk3NjBkNDJjZWExYTU1ZWQxZGJiOTVlMjJkNmVjZGY3M2FjY2U3NmYzOTc2MzU5YzQ4YzI3ODMzMzYzN2I5NmZkODNmNjY5NzQ4ZjNhNzU2Yjg2M2I2NGRkZTlkMTdkMmIwNzczYmM4MjFmMTdkMDg2ZDE1ZTQwNjYxNWEyZTIxNWVjNWExZjU1OGU3MjFhODBmMTQwYWI5OVwiLFwia2V5X2lkXCI6XCIxXCIsXCJzaWduXCI6XCI0YmM3ZGFmM1wifSIsInIiOiJodHRwczovL2NkLmxpYW5qaWEuY29tL3p1ZmFuZy9qaW5yb25nY2hlbmcvcGcycnQyMDA2MDAwMDAwMDEvIiwib3MiOiJ3ZWIiLCJ2IjoiMC4xIn0="
               }
    req = urllib.request.Request(url,headers=headers)
    response = urllib.request.urlopen(req)
    return response.read()

def parse_info(html):
    soup = BeautifulSoup(html, 'html.parser')
    AD = soup.find('div',class_='content__list--item')
    if AD:
        AD.decompose()
    house = []
    name =''
    area =''
    decorate = ''
    check=''
    floor=''
    total_floor=''
    rentFee =''
    for items in soup.find_all('div',class_='content__list--item'):
        main =items.find('div',class_='content__list--item--main') 
        text =main.find('p',class_='content__list--item--des') 
        name =''
        for i in text.find_all('a'):
            name +=i.text
        # if name=='':
        #     continue
        #提取文本并分割
        mes = text.text
        # 使用空格或 '/' 分割
        parts = mes.split('/')
        # 遍历分割结果，找出包含 "㎡" 的部分
        for part in parts:
            if '㎡' in part:
                area = part.strip()
                break

        span_hide = text.find('span', class_='hide')  # 先检查是否找到 span 标签
        if span_hide:  # 如果找到了标签
            temp = span_hide.get_text(strip=True).replace(" ","").split("（")
            floor = temp[0].replace("/","")  # 匹配楼层
            total_floor = temp[1].replace("）","")  # 匹配总楼层
        else:
            floor = '未知楼层'  # 默认值或错误处理
            total_floor = '未知层数'  # 默认值或错误处理

        text = main.find('p',class_='content__list--item--bottom oneline')
        if text.find('i',class_='content__item__tag--decoration'):
            decorate = text.find('i',class_='content__item__tag--decoration').text
        if text.find('i',class_='content__item__tag--gov_certification'):
            check =text.find('i',class_='content__item__tag--gov_certification').text
        
        rentFee = main.find('span',class_='content__list--item-price').find('em').text
        house.append({'name': name,
            'area': area,
            'floor': floor,
            'total_floor': total_floor,
            'decorate': decorate,
            'check': check,
            'rentFee': rentFee})
    return house
        
# 保存数据到Excel文件
def save_to_excel(filename,data):
    df = pd.DataFrame(data)
    df.to_excel(filename, index=False)

def crawAllPage(start,end):
    local_content = []
    for i in range(start,end):
        if i==0:
            continue
        elif i==1:
            page ="rt200600000001"
        else:
            page = "pg"+f"{i}"+"rt200600000001"
        pagelink = f"https://cd.lianjia.com/zufang/jinrongcheng/"+page+f"/#contentList"
        local_content.extend(parse_info(get_html(pagelink)))
        if printLock:
            print(f"page{i}爬取成功")
    contentQueue.put(local_content)

contentQueue = queue.Queue()
printLock= threading.Lock()
threads =[]
content =[]

if __name__=='__main__':
    for i in range(1,6):
        t = threading.Thread(target=crawAllPage,args=((i-1)*9,i*9))
        threads.append(t)
        t.start()
    for t in threads:
        t.join()
    while not contentQueue.empty():
        content.extend(contentQueue.get())
    save_to_excel(f"house/lianjia.xlsx",content)