import pandas as pd
import re
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import MinMaxScaler

file = f'./house/lianjia.xlsx'
tempFile = f'./house/temp.xlsx'



def getExcelData(filePath):
    df = pd.read_excel(filePath)
    # 提取每一行为字典，组合成列表
    # dataDict = [row.to_dict() for _, row in df.iterrows()]
    # return dataDict
    return df
def process_rent_fee(rent_fee):
    # 使用正则表达式提取数字
    match = re.search(r"\d+", rent_fee)
    if match:
        return float(match.group()) / 1000
    return None  # 处理无法匹配的情况

def filter(df):
    # 2. 过滤 'area' 列的缺失值
    df = df[df['area'].notnull()]
    df['area'] = df['area'].replace('㎡', '', regex=True)

    # 3. 填充 'decorate' 列的缺失值为 '非精装'
    df['decorate'].fillna('非精装', inplace=True)

    # 4. 填充 'floor' 列的缺失值为 '未给出'
    df['floor'].fillna('未给出', inplace=True)

    # 5. 将 'total_floor' 列中的 '层' 替换为空字符串
    df['total_floor'] = df['total_floor'].replace('层', '', regex=True)

    # 6. 提取特定楼盘数据
    df = df[df['name'].isin(["高新金融城招商玺荟", "高新金融城复地金融岛湾流汇"])]


    # 6. 特征编码
    df['decorate'] = df['decorate'].map({'非精装': 0, '精装': 1})
    df['floor'] = df['floor'].map({'低楼层': 1, '中楼层': 2, '高楼层': 3, '未给出': 0})

    # 7. 'rentFee' 列除以 1000
    if 'rentFee' in df.columns:
    # 处理 rentFee 列的代码
        df['rentFee'] = df['rentFee'].apply(process_rent_fee)
    else:
        pass
    df.to_excel(tempFile,index=False)
    return df

def analyse(filePath):
    df = pd.read_excel(tempFile)
    # 1. 单变量回归分析
    # 数据归一化
    scaler = MinMaxScaler()
    df['area'] = scaler.fit_transform(df[['area']])

    # 数据集拆分
    X_single = df[['area']]  # 特征
    y = df['rentFee']  # 标签
    X_train_single, X_test_single, y_train, y_test = train_test_split(X_single, y, test_size=0.3, random_state=42)

    # 单变量线性回归分析
    model_single = LinearRegression()
    model_single.fit(X_train_single, y_train)

    # 预测
    y_train_pred_single = model_single.predict(X_train_single)
    y_test_pred_single = model_single.predict(X_test_single)

    # 计算训练和测试误差
    train_error_single = mean_squared_error(y_train, y_train_pred_single)
    test_error_single = mean_squared_error(y_test, y_test_pred_single)

    print(f"单变量回归训练集误差 (MSE): {train_error_single:.4f}")
    print(f"单变量回归测试集误差 (MSE): {test_error_single:.4f}")

    # 2. 多变量回归分析
    # 特征数据归一化
    df[['area', 'total_floor']] = scaler.fit_transform(df[['area', 'total_floor']])
    
    # 多变量特征选择
    X_multi = df[['area', 'decorate', 'floor', 'total_floor']]

    # 数据集拆分
    X_train_multi, X_test_multi, y_train_multi, y_test_multi = train_test_split(X_multi, y, test_size=0.3, random_state=42)

    # 多变量线性回归分析
    model_multi = LinearRegression()
    model_multi.fit(X_train_multi, y_train_multi)

    # 预测
    y_train_pred_multi = model_multi.predict(X_train_multi)
    y_test_pred_multi = model_multi.predict(X_test_multi)

    # 计算训练和测试误差
    train_error_multi = mean_squared_error(y_train_multi, y_train_pred_multi)
    test_error_multi = mean_squared_error(y_test_multi, y_test_pred_multi)

    print(f"多变量回归训练集误差 (MSE): {train_error_multi:.4f}")
    print(f"多变量回归测试集误差 (MSE): {test_error_multi:.4f}")
    return model_single,model_multi


if __name__ == "__main__":
    filter(getExcelData(file))
    single,multi = analyse(tempFile)
    df = filter(getExcelData(f'./house/new_houses.xls'))

    # 特征数据归一化
    scaler = MinMaxScaler()
    df[['area', 'total_floor']] = scaler.fit_transform(df[['area', 'total_floor']])

    # 多变量特征选择
    X_multi = df[['area', 'decorate', 'floor', 'total_floor']]

    # 使用已有的 multi 模型进行预测
    y_pred_multi = multi.predict(X_multi)

    # 打印预测结果
    df['predicted_rentFee'] = y_pred_multi
    print(df[['name','area', 'decorate', 'floor', 'total_floor', 'predicted_rentFee']])



