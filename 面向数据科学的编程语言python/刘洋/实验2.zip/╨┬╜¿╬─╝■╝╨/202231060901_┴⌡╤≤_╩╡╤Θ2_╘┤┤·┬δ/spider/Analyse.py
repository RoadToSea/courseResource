import numpy as np
import pandas as pd
import wordcloud
import jieba
from collections import Counter
import re

def getCol(filePath):
    data = pd.read_excel(filePath)
    print(data[0:6])

def getBlank(filePath):
    data = pd.read_excel(filePath)
    data.replace("",np.nan,inplace=True)
    blank = data.isna().sum()
    print(f" 刘洋202231060901 于 2024/9/19 统计的 火星救援 影片数据缺失值为:\n  name:{blank[0]}\nscore:{blank[1]}\ntime:{blank[2]}\nusefulNum:{blank[3]}\ncomment:{blank[4]}")
    

def getAvrScore(filePath):
    data = pd.read_excel(filePath)
    totalScore =0
    totalNum   =0
    for scoreItem in data['score']:
        if not pd.isna(scoreItem):
            totalScore+=scoreItem
            totalNum +=1
    return totalScore/totalNum

def getRecommendNum(filePath):
    data = pd.read_excel(filePath)
    totalNum = 0
    for scoreItem in data['score']: 
        if(scoreItem==10):
            totalNum+=1
    return totalNum

def getInfoCorr(filePath):
    data = pd.read_excel(filePath)
    dataFilter = data.dropna(subset=['score','usefulNum'])
    corrNum = dataFilter['score'].corr(dataFilter['usefulNum'])
    return corrNum


def findUsefulComment(filePath):
    data = pd.read_excel(filePath)
    dataFilter = data.dropna(subset=['usefulNum'])
    dataFilter=dataFilter.sort_values(by='usefulNum',ascending=False)
    return dataFilter.iloc[0]['comment']

def wordPic(filePath):
    info = pd.read_excel(filePath)
    comments = ""
    for item in info['comment'] :
        comments += item
    comments = re.sub(r'[，,。 !！《》我在也是了的不和都就很但]','',comments)
    ls = jieba.lcut(comments)
    word_freq = Counter(ls)
    #将分好的词连接成字符串
    w = wordcloud.WordCloud(font_path = "msyh.ttc",\
    width = 1000,height = 700,\
    background_color = "white",\
    max_words = 50)
    #输出到文件
    w.generate_from_frequencies(word_freq)
    w.to_file('./douban .jpeg')
    
    # 找到频率最高的 3 个词
    top_3_words = word_freq.most_common(3)
    return top_3_words
    

if __name__ =="__main__":
    getBlank(f'spider/info.xlsx')
    print('*'*50)
    score = getAvrScore(f'spider/info.xlsx')
    print(f"score:{score}")
    print('*'*50)
    number = getRecommendNum(f'spider/info.xlsx')
    print(f"number:{number}")
    print('*'*50)
    corrNum = getInfoCorr(f'spider/info.xlsx')
    print(f"corrNum:{corrNum}")
    print('*'*50)
    comment = findUsefulComment(f'spider/info.xlsx')
    print(f"comment:{comment}")
    print('*'*50)
    words = wordPic(f'spider/info.xlsx')
    print(words)
    print('*'*50)
    