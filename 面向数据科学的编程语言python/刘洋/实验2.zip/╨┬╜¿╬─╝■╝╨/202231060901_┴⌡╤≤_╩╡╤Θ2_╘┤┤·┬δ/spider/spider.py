import urllib.request
from bs4 import BeautifulSoup
import pandas as pd
import jieba
import wordcloud

# 获取网页内容
def get_html(url):
    headers = {'user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0',
               'cookie':'''bid=dm3Z71-MD4g; _cc_id=b5a4cdff4ce1227204f52db27c8f3acd; __gads=ID=b30f89bf85496ece:T=1712552779:RT=1712553360:S=ALNI_Mah6Wdb49xlT4xhCcg19ohiAyqgeQ; __gpi=UID=00000ddd03c8bce4:T=1712552779:RT=1712553360:S=ALNI_MatNk6x-YKZc1Nh7s8MWQxDGnhFhw; __eoi=ID=ec1ee7e666a81b94:T=1712552779:RT=1712553360:S=AA-AfjYYG6eVunzNlO6oR3aTl0R1; _ga_KY2XQG4Q00=GS1.1.1712552787.1.1.1712553364.60.0.275272654; _ga_YD7QXHZJ4Y=GS1.1.1712553394.1.0.1712553394.0.0.0; ll="118318"; _pk_id.100001.4cf6=870d4c2ebd3eb359.1718189713.; _ga_RXNMP372GL=GS1.1.1720278687.1.1.1720278753.57.0.0; _ga=GA1.2.1430971787.1712552788; _ga_Y4GN1R87RG=GS1.1.1720278507.1.1.1720279744.0.0.0; viewed="26265745_2334288_26923390_5246800"; __utma=30149280.1320404150.1712552772.1720838801.1726394679.4; __utmc=30149280; __utmz=30149280.1726394679.4.4.utmcsr=cn.bing.com|utmccn=(referral)|utmcmd=referral|utmcct=/; __utmb=30149280.1.10.1726394679; _pk_ref.100001.4cf6=%5B%22%22%2C%22%22%2C1726394682%2C%22https%3A%2F%2Fcn.bing.com%2F%22%5D; _pk_ses.100001.4cf6=1; __utma=223695111.1430971787.1712552788.1726394682.1726394682.1; __utmb=223695111.0.10.1726394682; __utmc=223695111; __utmz=223695111.1726394682.1.1.utmcsr=cn.bing.com|utmccn=(referral)|utmcmd=referral|utmcct=/; ap_v=0,6.0; __yadk_uid=k2qHdK2sGyKYw3VIJzfbzbkYlJg5EAGA; _vwo_uuid_v2=D32B9F4CBD08349294D7D76EF1189F65F|a0fda6d14944d1e6345298245d45d4cf; dbcl2="283557242:NwEGdAHe7Vo"; ck=Oqe_; push_noty_num=0; push_doumail_num=0'''}
    req = urllib.request.Request(url, headers=headers)
    response = urllib.request.urlopen(req)
    return response.read()

# 解析评论数据
def parse_comments(html):
    soup = BeautifulSoup(html, 'html.parser')
    comments = []
    for item in soup.find_all('div', class_='comment-item'):
        firstLine = item.find('span',class_='comment-info')
        name = firstLine.find('a').text
        score_tag=firstLine.find_all('span')[1].get('title')
        score = ''
        if(score_tag=='力荐'): score = '10'
        elif(score_tag=='推荐'): score = '8'
        elif(score_tag=='还行'): score = '6'
        elif(score_tag=='较差'): score = '3'
        elif(score_tag=='很差'): score = '1'
        time = firstLine.find('span',class_='comment-time').text.strip()
        usefulNum = item.find('span',class_='votes vote-count').text
        comment = item.find('p', class_='comment-content').find('span').text
        comments.append({
        "name": name,
        "score": score, 
        "time": time,
        "usefulNum": usefulNum,
        "comment": comment
        })

    return comments

# 获取指定页数的评论数据
def get_comments(movie_id, pages):
    all_comments = []
    for page in range(pages):
        url = f'https://movie.douban.com/subject/{movie_id}/comments?start={page * 20}&limit=20&status=P&sort=new_score'
        html = get_html(url)
        comments = parse_comments(html)
        all_comments.extend(comments)
    return all_comments

# 保存数据到Excel文件
def save_to_excel(filename,data):
    df = pd.DataFrame(data)
    df.to_excel(filename, index=False)



# 主函数3
if __name__ == '__main__':
  #infoList = parse_comments(get_html(f"https://movie.douban.com/subject/25864085/comments?status=P"))
  print("start")
  info = get_comments(25864085,20)
  save_to_excel(f'spider/info.xlsx',info)
