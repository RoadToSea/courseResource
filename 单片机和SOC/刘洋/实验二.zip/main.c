/*
 * Copyright (c) 2006-2024, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2024-05-20     RT-Thread    first version
 */
#include <rtthread.h>
#define DBG_TAG "main"
#define DBG_LVL DBG_LOG
#include <rtdbg.h>
#include <rtdevice.h>



    rt_base_t LED1_PIN_NUM;
    rt_base_t LED2_PIN_NUM;
    rt_base_t LED3_PIN_NUM;
    rt_base_t LED4_PIN_NUM;

    rt_base_t keynum1;
    rt_base_t keynum2;
    rt_base_t beepnum;
    rt_base_t Vib;
    rt_base_t soundtest1;
    rt_base_t soundtest2;
    rt_base_t soundtest3;

    void init_sound(void)
    {
        soundtest1 = rt_pin_get("GND");
        soundtest2 = rt_pin_get("VCC");
        soundtest3 = rt_pin_get("PC.0");

        rt_pin_mode(soundtest1, PIN_MODE_INPUT);
        rt_pin_mode(soundtest2, PIN_MODE_INPUT);
        rt_pin_mode(soundtest3, PIN_MODE_INPUT);
    }
    void init_led(void)
    {

    LED1_PIN_NUM = rt_pin_get("PE.0");
    LED2_PIN_NUM = rt_pin_get("PE.1");
    LED3_PIN_NUM = rt_pin_get("PE.2");
    LED4_PIN_NUM = rt_pin_get("PE.3");

    rt_pin_mode(LED1_PIN_NUM,PIN_MODE_OUTPUT);
    rt_pin_mode(LED2_PIN_NUM, PIN_MODE_OUTPUT);
    rt_pin_mode(LED3_PIN_NUM, PIN_MODE_OUTPUT);
    rt_pin_mode(LED4_PIN_NUM,PIN_MODE_OUTPUT);

    rt_pin_write(LED1_PIN_NUM, PIN_HIGH);
    rt_pin_write(LED2_PIN_NUM, PIN_HIGH);
    rt_pin_write(LED3_PIN_NUM, PIN_HIGH);
    rt_pin_write(LED4_PIN_NUM, PIN_HIGH);
    }

   /* void init_key_port(void)
    {
        keynum1=rt_pin_get("PB.12");
        keynum2=rt_pin_get("PB.13");
        rt_pin_mode(keynum1,PIN_MODE_INPUT);
        rt_pin_mode(keynum2,PIN_MODE_INPUT);
    }*/

    static unsigned char var=0x01;

    void write_led(unsigned char cmd)

    {
        if (cmd & 0x01)
        rt_pin_write(LED1_PIN_NUM, PIN_LOW);
        else
        rt_pin_write(LED1_PIN_NUM, PIN_HIGH);

        if (cmd & (0x01<<1))
        rt_pin_write(LED2_PIN_NUM, PIN_LOW);
        else
        rt_pin_write(LED2_PIN_NUM, PIN_HIGH);

        if (cmd & (0x01<<2))
        rt_pin_write(LED3_PIN_NUM, PIN_LOW);
        else
        rt_pin_write(LED3_PIN_NUM, PIN_HIGH);

        if (cmd & (0x01<<3))
            rt_pin_write(LED4_PIN_NUM, PIN_LOW);
            else
            rt_pin_write(LED4_PIN_NUM, PIN_HIGH);
    }

    void high_loop_led(void)
    {
      write_led(var);
      var=(var<<1);
      if(var==0x10)
          var=0x01;
      rt_thread_mdelay(50);
   }




    void low_loop_led(void)
    {
        write_led(var);
        var=(var<<1);
        if(var==0x10)
            var=0x01;
        rt_thread_mdelay(500);
    }



    void reset(void)
    {
        rt_pin_write(LED1_PIN_NUM, PIN_HIGH);
        rt_pin_write(LED2_PIN_NUM, PIN_HIGH);
        rt_pin_write(LED3_PIN_NUM, PIN_HIGH);
        rt_pin_write(LED4_PIN_NUM, PIN_HIGH);
    }

    int  temp=0;
   /* void on_key1_clicked(void *args)
    {
        temp++;
        rt_kprintf("key1\n");
    }

    void init_interrupt1(void)//中断绑定
    {
       rt_pin_attach_irq(keynum1, PIN_IRQ_MODE_FALLING,on_key1_clicked, RT_NULL);

       rt_pin_irq_enable(keynum1,PIN_IRQ_ENABLE);


    }*/
    int count=0;

    void on_soundtest3_clicked(void *args)
    {

            rt_pin_irq_enable(soundtest3, PIN_IRQ_DISABLE);
            count++;
            if(count>=3){
            temp++;
            rt_kprintf("soundtest3\n");
            count=0;
            }
            rt_pin_irq_enable(soundtest3, PIN_IRQ_ENABLE);



    }

    void init_interrupt2(void)//中断绑定
    {
        rt_pin_attach_irq(soundtest3, PIN_IRQ_MODE_RISING,on_soundtest3_clicked, RT_NULL);
        rt_pin_irq_enable(soundtest3,PIN_IRQ_ENABLE);


    }


    int main(void)
    {

        //init_key_port();
        init_led();
        init_sound();
        //init_interrupt1();
        init_interrupt2();
        while(1)
        {

            if(temp==0)
            {
                high_loop_led();


            }
            else if(temp==1)
            {
                low_loop_led();

            }
            else if(temp==2)
            {
                reset();

            }
            else if(temp==3)
            {
                temp=0;

            }

            rt_thread_mdelay(100);
        }
        return RT_EOK;
    }


























